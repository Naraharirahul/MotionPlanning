Parameters chosen for 3_agents and 8_agents scenario file. 

Sensing radius = 10

Number of sample velocities which were sampled are: 200

During the trials, I have noticed that if more samples are created then the probability of the agents colliding increased.
Also, the computational time also increases slightly as the number of sample size increases. 

The given parameters were working just fine for both the scenarios:
Alpha = 1
Beta = 1
Gama = 2