Parameters chosen for crossing_agents scenario file. 

Sensing radius = 10

Number of sample velocities which were sampled are: 200

As said, I have only used 200 sample velocities. 

The following parameters were used: 

Alpha = 3
Beta = 5
Gama = 2

As Beta was increased, the agents were moving aroung the goal velocity but were not stopping at the goal position which made me to
increase the Alpha value as well. 

For Gama 2, it was working just fine. 