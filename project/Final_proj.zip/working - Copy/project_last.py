# prmplanner.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to Clemson University and the authors.
# 
# Author: Ioannis Karamouzas (ioannis@g.clemson.edu)

import numpy as np
from graph import RoadmapVertex, RoadmapEdge, Roadmap
from utils import *
import random
from math import sqrt
from math import *
import math
disk_robot = False #(change this to False for the advanced extension)


obstacles = None # the obstacles 
robot_radius = None # the radius of the robot
robot_width = None # the width of the OBB robot (advanced extension)
robot_height = None # the height of the OBB robot (advanced extension)


# ----------------------------------------
# modify the code below
# ----------------------------------------

# Construction phase: Build the roadmap
# You should incrementally sample configurations according to a strategy and add them to the roadmap, 
# select the neighbors of each sample according to a distance function and strategy, and
# attempt to connect the sample to its neighbors using a local planner, leading to corresponding edges
# See graph.py to get familiar with the Roadmap class
distance_app = []
def build_roadmap(q_range, robot_dim, scene_obstacles):

    global obstacles, robot_width, robot_height, robot_radius

    graph = Roadmap()

    obstacles = scene_obstacles # setting the global obstacle variable
    x_limit = q_range[0] # the range of x-positions for the robot
    y_limit = q_range[1] # the range of y-positions for the robot
    theta_limit = q_range[2] # the range of orientations for the robot (advanced extension)
    robot_width, robot_height = robot_dim[0], robot_dim[1] # the dimensions of the robot, represented as an oriented bounding box
    robot_radius = max(robot_width, robot_height) / 2.
    for i in range(0, 1):
        xo = 1 + i * 5
        for j in range(0, 1):
            yo = 1 + j * 5
            xon = xo*cos(math.radians(0.1)) - yo*sin(math.radians(0.1))
            yon = yo*cos(math.radians(0.1)) + xo*sin(math.radians(0.1))
            theta = [45, 135, 225, 315]
            graph.addVertex((xon, yon))
            # theta = [90]
            for k in range(len(theta)):
                r = 5
                x1 = xo + r * math.cos(math.radians(theta[k]))
                y1 = yo + r * math.sin(math.radians(theta[k]))
                x1n = x1*cos(math.radians(0.1)) - y1*sin(math.radians(0.1))
                y1n = y1*cos(math.radians(0.1)) + x1*sin(math.radians(0.1))


    return graph

def find_path(q_start, q_goal, graph):
    path = []
    parent = {}
    check = []

    l = 4.5  #Turning radius
    beta = 30 #Minimum steering angle

    # For parallel parking
    # q_start = (3, 5, 90.0000001)
    # q_goal = (35,6,-89.9999999) # top right parallel parking spot
    #
    # q_start = (3,5,90.0000001)
    # q_goal = (25,6,-89.9999999)  # top left parking spot

    # q_start = (3, 5, 90.0000001)
    # q_goal = (37.1913418899608, 24.044228693735096, 9.999999406318238e-08)#perpendicular parking
    # q_start = (3,5,0.0000001)
    # q_goal = (19, 36, 9.999999406318238e-08) # Bottom parallel parking spot

    # print(q_start)
    # q_goal_theta = 90 - math.degrees(q_goal[2])
    # q_goal[2] = q_goal_theta
    # print(q_goal_theta)
    x_new = 0
    y_new = 0
    x = q_start[0]
    y= q_start[1]
    theta = q_start[2]

    closed_set = OrderedSet()
    open_set = PriorityQueue(order=min, f=lambda v: v.f)
    g = 0
    h = 3 #distance(q_start,q_goal)
    f = g + h
    open_set.put(q_start, Value(f=f, g=g))

    cc = 0
    while len(open_set) > 0:
        neighbour = []
        next, value = open_set.pop()
        closed_set.add(next)
        g = value.g
        x = next[0]
        y = next[1]
        theta = next[2]
        add = 0
        if next == q_goal:
            while not next == q_start:
                path.insert(1, (next[0], next[1], math.radians(90 - next[2])))
                next = parent[next]
                add = 0
            break
        elif (next[2]==q_goal[2]) and (distance(x,y,q_goal[0],q_goal[1])<3):
            if round(x) != round(q_goal[0]) or round(y) != round(q_goal[1]):
                if round(theta) == 90 or round(theta) == -90:
                    x_new = x
                    y_new = q_goal[1]
                else:
                    x_new = q_goal[0]
                    y_new = y
                path.insert(0, (x_new, y_new, math.radians(90 - next[2])))
                d = distance(x_new, y_new, q_goal[0], q_goal[1])
                # print('distance',d)
                add = 1
                while not next == q_start:
                    path.insert(1, (next[0], next[1], math.radians(90 - next[2])))
                    next = parent[next]
                    # print("next",next)
                break
        else:

            ycl = y + l * math.cos(math.radians(theta))     # Left center
            xcl = x + math.tan(math.radians(theta)) * (y - ycl)

            # left child coordinates:
            ynl = ycl + l * math.sin(math.radians(theta - beta))
            xnl = xcl - (ycl - ynl) / math.tan(math.radians(theta - beta))
            # print("left", xnl, ynl)
            gamaL = theta + beta
            neighbour_l = (xnl,ynl,gamaL)
            if collision(xnl, ynl) is True:
                neighbour.append(neighbour_l)
                # print('left', neighbour_l)

            ycr = y - l * math.cos(math.radians(theta))     # Right center
            xcr = x + math.tan(math.radians(theta)) * (y - ycr)

            # rightChild coordinates:
            ynr = ycr + l * math.sin(math.radians(theta + beta))
            xnr = xcr - (ycr - ynr) / math.tan(math.radians(theta + beta))
            gamaR = theta - beta
            # print("right", xnr, ynr, gamaR)
            neighbour_r = (xnr,ynr,gamaR)
            if collision(xnr,ynr) is True:
                neighbour.append(neighbour_r)
                # print('right', neighbour_r)

            # straight child coordinates
            yns = y + l * math.sin(math.radians(theta))
            xns = x - (y - yns) / math.tan(math.radians(theta))
            gamaS = theta
            neighbour_s = (xns,yns,gamaS)
            if collision(xns, yns) is True:
                neighbour.append(neighbour_s)
                # print('straight',neighbour_s)

            for i in neighbour:
                x_child = i[0]
                y_child = i[1]
                theta_child = i[2]
                check.append(next)
                if i not in check:
                    parent.update({i: next})
                if i not in closed_set:
                    g_child = g + distance(x,y,x_child,y_child)
                if i not in open_set or open_set.get(i).g > g_child:
                    h_child = distance(x_child,y_child,q_goal[0],q_goal[1])
                    f_child = g_child + h_child
                    open_set.put(i,Value(f_child,g_child))
#-------------------------------------------------------


    #Horizontal distance from the goal point at which the car should start parking parallely

    if add == 1:
        alpha1 = acos(l/(l + d/2))
        alpha = math.degrees(alpha1)
        if q_goal[0] != x_new:
            if q_goal[0] > x_new:
                right_parking(x_new, y_new, alpha, theta, path, q_goal, d, l)
            else:
                left_parking(x_new, y_new, alpha, theta, path, q_goal, d, l)
        else:
            if q_goal[1] > y_new:
                right_parking(x_new, y_new, alpha, theta, path, q_goal, d, l)
            else:
                left_parking(x_new, y_new, alpha, theta, path, q_goal, d, l)
    return path
# ----------------------------------------
# below are some functions that you may want to populate/modify and use above 
# ----------------------------------------

def left_parking(x_new,y_new,alpha,theta,path,q_goal,d,l):

    plcy = y_new + l * math.cos(math.radians(theta))  # Left center
    plcx = x_new + math.tan(math.radians(theta)) * (y_new - plcy)

    # left child coordinates:
    plny = plcy + l * math.sin(math.radians(theta - alpha))
    plnx = plcx - (plcy - plny) / math.tan(math.radians(theta - alpha))


    dia = 2 * (l + d / 2) * sin(math.radians(90 + alpha))

    prcy = plny - dia * math.cos(math.radians(90 - (q_goal[2] - alpha)))  # Right center
    prcx = plnx + math.tan(math.radians(90 - (q_goal[2] - alpha))) * (plny - prcy)
    # if collision(plcx,plcy) and collision(plnx,plny) and collision(q_goal[0],q_goal[1]) is True:
    path.insert(0, (plnx, plny, math.radians(90 - (q_goal[2] + alpha))))
    path.insert(0, (prcx, prcy, math.radians(90 - (q_goal[2] + alpha))))
    path.insert(0, (q_goal[0], q_goal[1], math.radians(90 - q_goal[2])))
    # else:
    #     print('cannot park in the given space!')
def right_parking(x_new,y_new,alpha,theta,path,q_goal,d,l):

    rcy = y_new - l * math.cos(math.radians(q_goal[2]))  # Right center
    rcx = x_new + math.tan(math.radians(q_goal[2])) * (y_new - rcy)

    rny = rcy + l * math.sin(math.radians(q_goal[2] + alpha))
    rnx = rcx - (rcy - rny) / math.tan(math.radians(q_goal[2] + alpha))
    # print('xnr,ynr,d', rnx, rny, d, math.radians(90 - (q_goal[2] - alpha)))

    dia = 2 * (l + d / 2) * sin(math.radians(90 + alpha))

    lcy = rny + dia * math.cos(math.radians(90 + (q_goal[2] - alpha)))  # Left center
    lcx = rnx + math.tan(math.radians(90 + (q_goal[2] - alpha))) * (rny - lcy)
    # if collision(rnx, rny) and collision(lcx,lcy) and collision(q_goal[0],q_goal[1]) is True:
    path.insert(0, (rnx, rny, math.radians(90 - (q_goal[2] - alpha))))  # Point 2
    path.insert(0, (lcx, lcy, math.radians(90 - (q_goal[2] - alpha))))  # Point 3
    path.insert(0, (q_goal[0], q_goal[1], math.radians(90 - q_goal[2]))) # Point 4

    # else:
    #     print('cannot park in the given space!')
def distance (m1, n1, m2, n2):

    distance_new = sqrt((m1 - m2)**2 + (n1 - n2)**2)
    return distance_new

def collision(x,y):

    for j in range(0, 13):
        xs = []
        ys = []
        for point in obstacles[j].points:
            count = 0
            xs.append(point[0])
            ys.append(point[1])
            x_min = min(xs) - robot_height
            x_max = max(xs) + robot_height
            y_min = min(ys) - robot_height
            y_max = max(ys) + robot_height
        if x_min <= x <= x_max and y_min <= y <= y_max:
            count = 1
            break
    if count != 1:
        return True

if __name__ == "__main__":
    from scene import Scene
    import tkinter as tk

    win = tk.Tk()
    Scene('prm1.csv', disk_robot, (build_roadmap, find_path), win)
    win.mainloop()
