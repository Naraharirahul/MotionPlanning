To run the code, please follow the following steps:

1. Click on generat start point which would create a start vertex.
2. By clicking on the perpendicular parking button, a perpendicular parking scenario with start and goal will be visible.
3. To generate the path for that orientation, click on the button get path.
4. For generating the parallel parking scenarios, click on the random parallel parking space button which shall generate 3 different cases by each click.
5. For path generation, click on the button get path.



