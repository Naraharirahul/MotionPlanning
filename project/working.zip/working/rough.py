import math
from math import pi
a = math.cos(pi/4)
print("a",a)