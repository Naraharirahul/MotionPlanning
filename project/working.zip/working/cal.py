
import math
a=math.pi/2
print(a)
print(math.cos((a)))

b = 90*0.017453
print("b",math.cos(b))

c= 90
cd=math.cos(math.radians(c))
print("cd", cd, 'rounded', round(cd, 2))


