The parameters are:

TTC forces are calculated in this code.

The value of epsilon = 0.2

The forces are limited to maximum value of 7 and -7.

The Sensing radius is taken as 7.

number of iterations = 500