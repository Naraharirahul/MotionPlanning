The parameters are:

The Power law has been implemeted with following parameters:

The value of epsilon = 0
k = 2
Sensing radius = 7
max force applied is 10.
number of iterations = 500
