The parameters are:

The Adversarial uncertainity model has been implemented on the PowerLaw model.

The value of epsilon = 0.2

v = 0

k = 2

number of iterations = 500