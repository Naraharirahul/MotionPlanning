For different values of epsilon, there are different codes which are saved in seperate folders.

Each folder has its own README text file which indicates the parameters used.